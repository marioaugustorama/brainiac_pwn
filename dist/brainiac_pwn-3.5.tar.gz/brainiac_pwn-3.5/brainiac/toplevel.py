import brainiac_libs
#from brainiac_libs import *

from brainiac_libs.utils.convert import Convert
from brainiac_libs.utils.cores import Cores
from brainiac_libs.utils.decode import Decode
from brainiac_libs.utils.hash_encode import Hash_encode
from brainiac_libs.utils.encode import Encode
from brainiac_libs.utils.debug import Debug
from brainiac_libs.utils.gera_wordlist import Gera_wordlist
#from brainiac_libs.utils import *


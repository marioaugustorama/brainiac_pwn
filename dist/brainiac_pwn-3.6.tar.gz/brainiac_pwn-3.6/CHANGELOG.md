# Changelog

Esse changelog inclui apenas recursos e alterações maiores. Bugfixes e
pequenas alterações são omitidas.

## Histórico de lançamento
A tabela abaixo mostra qual versão corresponde a cada ramo, e em que data a versão foi lançada.


| Version          | Branch   | Release Date           |
| ---------------- | -------- | ---------------------- |
| [3.4](#)         | `dev`    | 18 de Março de 2018    |
